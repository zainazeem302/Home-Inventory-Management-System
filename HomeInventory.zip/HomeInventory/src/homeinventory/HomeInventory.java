package homeinventory;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import com.toedter.calendar.JDateChooser;
import java.awt.geom.*;
import java.io.*;

public class HomeInventory extends javax.swing.JFrame {
    final int maximumEntries = 300;
      int numberEntries;
      InventoryItem[] myInventory = new InventoryItem[maximumEntries];

    private JToolBar inventoryToolBar = new JToolBar();
    private JButton newButton = new JButton(new ImageIcon("new.gif"));
    private JButton deleteButton = new JButton(new ImageIcon("delete.gif"));
    private JButton saveButton = new JButton(new ImageIcon("save.gif"));
    private JButton previousButton = new JButton(new ImageIcon("previous.gif"));
    private JButton nextButton = new JButton(new ImageIcon("next.gif"));
    private JButton printButton = new JButton(new ImageIcon("print.gif"));
    private JButton exitButton = new JButton();

    private JLabel itemLabel = new JLabel("Inventory Item");
    private JTextField itemTextField = new JTextField();
    private JLabel locationLabel = new JLabel("Location");
    private JComboBox<String> locationComboBox = new JComboBox<>();
    private JCheckBox markedCheckBox = new JCheckBox("Marked?");
    private JLabel serialLabel = new JLabel("Serial Number");
    private JTextField serialTextField = new JTextField();
    private JTextField priceTextField = new JTextField();
    private JTextField noteTextField = new JTextField();
    private JTextField dateDateChooser = new JTextField();
    private JTextField storeTextField = new JTextField();
    private JButton photoButton = new JButton();
   
   

    public HomeInventory() {
        initComponents(); // Initialize the GUI components
        setTitle("Home Inventory Manager");
        setResizable(false);
        addWindowListener(new WindowAdapter() {

        });
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints;
        pack();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((int) (0.5 * (screenSize.width - getWidth())),
                (int) (0.5 * (screenSize.height - getHeight())),
                getWidth(), getHeight());
        // Toolbar setup
        inventoryToolBar.setFloatable(false);
        inventoryToolBar.setBackground(Color.BLUE);
        inventoryToolBar.setOrientation(SwingConstants.VERTICAL);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.gridheight = 8;
        gridConstraints.fill = GridBagConstraints.VERTICAL;
        getContentPane().add(inventoryToolBar, gridConstraints);

        // Add buttons and separators to the toolbar
        Dimension bSize = new Dimension(70, 50);
        addButton(newButton, "New", "Add New Item", bSize);
        addButton(deleteButton, "Delete", "Delete Current Item", bSize);
        addButton(saveButton, "Save", "Save Current Item", bSize);
        inventoryToolBar.addSeparator();
        addButton(previousButton, "Previous", "Display Previous Item", bSize);
        addButton(nextButton, "Next", "Display Next Item", bSize);
        inventoryToolBar.addSeparator();
        addButton(printButton, "Print", "Print Inventory List", bSize);
        addButton(exitButton, "Exit", "Exit Program", bSize);

        JLabel priceLabel = new JLabel();
        JTextField priceTextField = new JTextField();
        JLabel dateLabel = new JLabel();
        JDateChooser dateDateChooser = new JDateChooser();
        JLabel storeLabel = new JLabel();
        JTextField storeTextField = new JTextField();
        JLabel noteLabel = new JLabel();
        JTextField noteTextField = new JTextField();
        JLabel photoLabel = new JLabel();
        JTextArea photoTextArea = new JTextArea();
        JButton photoButton = new JButton();

        JPanel searchPanel = new JPanel();
        JButton[] searchButton = new JButton[26];

        searchPanel.setPreferredSize(new Dimension(240, 160));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Item Search"));
        searchPanel.setLayout(new GridBagLayout());
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 7;
        gridConstraints.gridwidth = 3;
        gridConstraints.insets = new Insets(10, 0, 10, 0);
        gridConstraints.anchor = GridBagConstraints.CENTER;
        getContentPane().add(searchPanel, gridConstraints);
        int x = 0, y = 0;
        for (int i = 0; i < 26; i++) {
            searchButton[i] = new JButton();
            searchButton[i].setText(String.valueOf((char) (65 + i)));
            searchButton[i].setFont(new Font("Arial", Font.BOLD, 12));
            searchButton[i].setMargin(new Insets(-10, -10, -10, -10));
            sizeButton(searchButton[i], new Dimension(37, 27));
            searchButton[i].setBackground(Color.YELLOW);
            gridConstraints = new GridBagConstraints();
            gridConstraints.gridx = x;
            gridConstraints.gridy = y;
            searchPanel.add(searchButton[i], gridConstraints);
            searchButton[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    searchButtonActionPerformed(e);
                }
            });
            x++;
            if (x % 6 == 0) {
                x = 0;
                y++;
            }
        }
        

        priceLabel.setText("Purchase Price");
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 3;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        gridConstraints.anchor = GridBagConstraints.EAST;
        getContentPane().add(priceLabel, gridConstraints);
        priceTextField.setPreferredSize(new Dimension(160, 25));
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 3;
        gridConstraints.gridwidth = 2;
        gridConstraints.insets = new Insets(10, 0, 0, 10);
        gridConstraints.anchor = GridBagConstraints.WEST;
        getContentPane().add(priceTextField, gridConstraints);
        dateLabel.setText("Date Purchased");
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 4;
        gridConstraints.gridy = 3;
        gridConstraints.insets = new Insets(10, 10, 0, 0);
        gridConstraints.anchor = GridBagConstraints.WEST;
        getContentPane().add(dateLabel, gridConstraints);
        dateDateChooser.setPreferredSize(new Dimension(120, 25));
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 5;
        gridConstraints.gridy = 3;
        gridConstraints.gridwidth = 2;
        gridConstraints.insets = new Insets(10, 0, 0, 10);
        gridConstraints.anchor = GridBagConstraints.WEST;
        getContentPane().add(dateDateChooser, gridConstraints);
        storeLabel.setText("Store/Website");
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 4;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        gridConstraints.anchor = GridBagConstraints.EAST;
        getContentPane().add(storeLabel, gridConstraints);
        storeTextField.setPreferredSize(new Dimension(400, 25));
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 4;
        gridConstraints.gridwidth = 5;
        gridConstraints.insets = new Insets(10, 0, 0, 10);
        gridConstraints.anchor = GridBagConstraints.WEST;
        getContentPane().add(storeTextField, gridConstraints);
        noteLabel.setText("Note");
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 5;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        gridConstraints.anchor = GridBagConstraints.EAST;
        getContentPane().add(noteLabel, gridConstraints);
        noteTextField.setPreferredSize(new Dimension(400, 25));
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 5;
        gridConstraints.gridwidth = 5;
        gridConstraints.insets = new Insets(10, 0, 0, 10);
        gridConstraints.anchor = GridBagConstraints.WEST;
        getContentPane().add(noteTextField, gridConstraints);
        photoLabel.setText("Photo");
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 6;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        gridConstraints.anchor = GridBagConstraints.EAST;
        getContentPane().add(photoLabel, gridConstraints);
        photoTextArea.setPreferredSize(new Dimension(350, 35));
        photoTextArea.setFont(new Font("Arial", Font.PLAIN, 12));
        photoTextArea.setEditable(false);
        photoTextArea.setLineWrap(true);
        photoTextArea.setWrapStyleWord(true);
        photoTextArea.setBackground(new Color(255, 255, 192));
        photoTextArea.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 6;
        gridConstraints.gridwidth = 4;
        gridConstraints.insets = new Insets(10, 0, 0, 10);
        gridConstraints.anchor = GridBagConstraints.WEST;
        getContentPane().add(photoTextArea, gridConstraints);
        photoButton.setText("...");
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 6;
        gridConstraints.gridy = 6;
        gridConstraints.insets = new Insets(10, 0, 0, 10);
        gridConstraints.anchor = GridBagConstraints.WEST;
        getContentPane().add(photoButton, gridConstraints);

        itemLabel.setText("Inventory Item");
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        gridConstraints.anchor = GridBagConstraints.EAST;
        getContentPane().add(itemLabel, gridConstraints);
        itemTextField.setPreferredSize(new Dimension(400, 25));
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        gridConstraints.gridwidth = 5;
        gridConstraints.insets = new Insets(10, 0, 0, 10);
        gridConstraints.anchor = GridBagConstraints.WEST;
        getContentPane().add(itemTextField, gridConstraints);
        locationLabel.setText("Location");
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        gridConstraints.anchor = GridBagConstraints.EAST;
        getContentPane().add(locationLabel, gridConstraints);
        locationComboBox.setPreferredSize(new Dimension(270, 25));
        locationComboBox.setFont(new Font("Arial", Font.PLAIN, 12));
        locationComboBox.setEditable(true);
        locationComboBox.setBackground(Color.WHITE);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 1;
        gridConstraints.gridwidth = 3;
        gridConstraints.insets = new Insets(10, 0, 0, 10);
        gridConstraints.anchor = GridBagConstraints.WEST;
        getContentPane().add(locationComboBox, gridConstraints);
        markedCheckBox.setText("Marked?");
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 5;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(10, 10, 0, 0);
        gridConstraints.anchor = GridBagConstraints.WEST;
        getContentPane().add(markedCheckBox, gridConstraints);
        serialLabel.setText("Serial Number");
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        gridConstraints.anchor = GridBagConstraints.EAST;
        getContentPane().add(serialLabel, gridConstraints);
        serialTextField.setPreferredSize(new Dimension(270, 25));
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 2;
        gridConstraints.gridwidth = 3;
        gridConstraints.insets = new Insets(10, 0, 0, 10);
        gridConstraints.anchor = GridBagConstraints.WEST;
        getContentPane().add(serialTextField, gridConstraints);

       
        PhotoPanel photoPanel = new PhotoPanel();

photoPanel.setPreferredSize(new Dimension(240, 160)); 
gridConstraints= new GridBagConstraints();
gridConstraints.gridx = 4;
gridConstraints.gridy = 7;
gridConstraints.gridwidth = 3;
gridConstraints.insets = new Insets(10, 0, 10, 10);
gridConstraints.anchor = GridBagConstraints.CENTER;
getContentPane().add(photoPanel, gridConstraints);  
       
       
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        gridConstraints.anchor = GridBagConstraints.EAST;
        getContentPane().add(itemLabel, gridConstraints);
        // Add controls to the frame
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        gridConstraints.gridwidth = 5;
        gridConstraints.insets = new Insets(10, 0, 0, 10);
        gridConstraints.anchor = GridBagConstraints.WEST;
        getContentPane().add(itemTextField, gridConstraints);
        // Set the frame properties
        setTitle("Home Inventory Manager");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);

     
       
        // Add action listener for itemTextField
itemTextField.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        itemTextFieldActionPerformed(e);
    }
});

// Corresponding method to move focus to the combo box (locationComboBox)


// Add action listener for locationComboBox
locationComboBox.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        locationComboBoxActionPerformed(e);
    }
});

// Corresponding method to move focus to serialTextField


// Add action listener for serialTextField
serialTextField.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        serialTextFieldActionPerformed(e);
    }
});

// Corresponding method to move focus to priceTextField

// Add action listener for priceTextField
priceTextField.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        priceTextFieldActionPerformed(e);
    }
});

// Corresponding method to move focus to dateDateChooser


// Add property change listener for dateDateChooser
dateDateChooser.addPropertyChangeListener(new PropertyChangeListener() {
    public void propertyChange(PropertyChangeEvent e) {
        dateDateChooserPropertyChange(e);
    }
});



// Add action listener for storeTextField
storeTextField.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        storeTextFieldActionPerformed(e);
    }
});

// Corresponding method to move focus to noteTextField


// Add action listener for noteTextField
noteTextField.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        noteTextFieldActionPerformed(e);
    }
});

// Corresponding method to move focus to photoButton


       
       
        photoButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                photoButtonActionPerformed(e);
            }
        });
    }

   
   
   
    private void addButton(JButton button, String text, String tooltip, Dimension size) {
        button.setText(text);
        sizeButton(button, size);
        button.setToolTipText(tooltip);
        button.setHorizontalTextPosition(SwingConstants.CENTER);
        button.setVerticalTextPosition(SwingConstants.BOTTOM);
        inventoryToolBar.add(button);
    }

    private void sizeButton(JButton button, Dimension size) {
        button.setPreferredSize(size);
        button.setMinimumSize(size);
        button.setMaximumSize(size);
    }

    private void searchButtonActionPerformed(ActionEvent e) {
     
    }

private void serialTextFieldActionPerformed(ActionEvent e) {
    priceTextField.requestFocus();
}

private void storeTextFieldActionPerformed(ActionEvent e) {
    noteTextField.requestFocus();
}

private void priceTextFieldActionPerformed(ActionEvent e) {
    dateDateChooser.requestFocus();
}

// Corresponding method to move focus to storeTextField
private void dateDateChooserPropertyChange(PropertyChangeEvent e) {
    storeTextField.requestFocus();
}
private void noteTextFieldActionPerformed(ActionEvent e) {
    photoButton.requestFocus();
}

private void itemTextFieldActionPerformed(ActionEvent e) {
    locationComboBox.requestFocus();
}

private void locationComboBoxActionPerformed(ActionEvent e) {
    serialTextField.requestFocus();
}

    // Action listeners for toolbar buttons
    private void newButtonActionPerformed(ActionEvent e) {
        // Add new item action
       
    }

    private void deleteButtonActionPerformed(ActionEvent e) {
        // Delete item action
    }

    private void saveButtonActionPerformed(ActionEvent e) {
        // Save item action
        JOptionPane.showMessageDialog(this, "Saving current item...");
    }

    private void previousButtonActionPerformed(ActionEvent e) {
        // Display previous item action
    }

    private void nextButtonActionPerformed(ActionEvent e) {
        // Display next item action
    }

    private void printButtonActionPerformed(ActionEvent e) {
        // Print inventory list action
    }

    private void exitButtonActionPerformed(ActionEvent e) {
        // Exit program action
        System.exit(0);
    }

    private void photoButtonActionPerformed(ActionEvent e) {
    }

    // Other generated code from GUI Builder
    private void initComponents() {
        // Your existing initComponents() code goes here
        // This method is removed since you'll manually add components
    }



    // Main method to launch the application
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomeInventory().setVisible(true);
               
            }
        });
    }
}
 class PhotoPanel extends JPanel {
        public void paintComponent(Graphics g) {
            Graphics2D g2D = (Graphics2D) g;
            super.paintComponent(g2D);
            // draw border
            g2D.setPaint(Color.BLACK);
            g2D.draw(new Rectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1));
            g2D.dispose();
        }
    }